from chesscrown.core.bot import chesscrownBot
from chesscrown.core.dir import dirr
from chesscrown.core.git import git
from chesscrown.core.userbot import Userbot
from chesscrown.misc import dbb, heroku

from .logging import LOGGER

git()


dirr()

dbb()

heroku()

# Clients
app = BikashBot()

userbot = Userbot()


from .platforms import *

YouTube = YouTubeAPI()
Carbon = CarbonAPI()
Spotify = SpotifyAPI()
Apple = AppleAPI()
Resso = RessoAPI()
SoundCloud = SoundAPI()
Telegram = TeleAPI()
